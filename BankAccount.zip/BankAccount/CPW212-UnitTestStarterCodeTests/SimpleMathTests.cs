﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CPW212_UnitTestStarterCode;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPW212_UnitTestStarterCode.Tests
{
    [TestClass()]
    public class SimpleMathTests
    {
        [TestMethod()]
        [DataRow(5, 10)]
        [DataRow(0, 100)]
        [DataRow(-1, -10)]
        [DataRow(0, -0)]
        public void Add_TwoNumbers_ReturnsSum(double num1, double num2)
        {
            double sum = num1 + num2;
            Assert.AreEqual(sum, SimpleMath.Add(num1, num2));
        }

        [TestMethod]
        public void Multiply_TwoNumbers_ReturnsProduct()
        {
            // Use a few pairs of values to test the Multiply method
            double productExcpected = 5 * 5;
            Assert.AreEqual(productExcpected, SimpleMath.Multiply(5, 5));
            productExcpected = 9 * 4;
            Assert.AreEqual(productExcpected, SimpleMath.Multiply(9, 4));
            productExcpected = 7 * 5;
            Assert.AreEqual(productExcpected, SimpleMath.Multiply(7, 5));
        }

        [TestMethod]
        public void Divide_DenominatorZero_ThrowsArgumentException()
        {
            // Divide by zero should throw an argument exception with a message
            // "Denominator cannot be zero"
            string errmsg = "Denominator cannot be zero";
            Assert.ThrowsException<DivideByZeroException>(() => SimpleMath.Divide(6, 0), errmsg);
        }

        // TODO: Test Divide method with two valid numbers
        [TestMethod]
        [DataRow(5, 10)]
        [DataRow(0, 100)]
        [DataRow(-1, -10)]
        public void Devide_TwoNumbers_ReturnsQuotient(double num1, double num2)
        {
            double quotient = num1 / num2;
            Assert.AreEqual(quotient, SimpleMath.Divide(num1, num2));
        }

        // TODO: Test subtract method with two valid numbers
        [TestMethod()]
        [DataRow(5, 10)]
        [DataRow(0, 100)]
        [DataRow(-1, -10)]
        [DataRow(0, -0)]
        public void Substract_TwoNumbers_ReturnsDifference(double num1, double num2)
        {
            double difference = num1 - num2;
            Assert.AreEqual(difference, SimpleMath.Subtract(num1, num2));
        }
    }
}